function updateTime(){
let hour=new Date().getHours();
let min=new Date().getMinutes();
let sec=new Date().getSeconds();
document.querySelector('.hour').innerHTML=hour;
document.querySelector('.min').innerHTML=min;
document.querySelector('.sec').innerHTML=sec;
    if(hour>=0 && hour<12){
        document.querySelector('.clock').style.background="url(assets/img/morning.jpg)";
        document.querySelector('.clock').style.backgroundSize="cover";
        document.querySelector('.clock').style.backgroundPositionY="-130px";
    }
    else if(hour>=12 && hour<15){
        document.querySelector('.clock').style.background="url(assets/img/afternoon.jpg)";
        document.querySelector('.clock').style.backgroundSize="cover";
        document.querySelector('.clock').style.backgroundPositionY="0px";
    }
    else if(hour>=15 && hour<18){
        document.querySelector('.clock').style.background="url(assets/img/evening.jpg)";
        document.querySelector('.clock').style.backgroundSize="cover";
        document.querySelector('.clock').style.backgroundPositionY="0px";
    }
    else if(hour>=18 && hour<24){
        document.querySelector('.clock').style.background="url(assets/img/night.jpg)";
        document.querySelector('.clock').style.backgroundSize="cover";
        document.querySelector('.clock').style.backgroundPositionY="-50px";
    }
}
setInterval(updateTime,1);